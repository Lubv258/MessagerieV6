
const socket=io();

function login(){
 socket.emit('login',username.value);
 loginBox.style.display='none';
 app.style.display='flex';
}

function send(){
 if(!msg.value.trim()) return;
 socket.emit('message',msg.value);
 msg.value='';
}

function addMessage(html){
 messages.innerHTML += html;
 messages.scrollTop=messages.scrollHeight;
}

socket.on('history',h=>h.forEach(m=>{
 addMessage(`<div class="msg"><b>${m.user}</b> (${m.time})<br>${m.text}</div>`);
}));

socket.on('message',m=>{
 addMessage(`<div class="msg"><b>${m.user}</b> (${m.time})<br>${m.text}</div>`);
});

socket.on('system',txt=>{
 addMessage(`<div class="msg">⚙️ ${txt}</div>`);
});

socket.on('users',list=>{
 users.innerHTML=list.map(u=>`<li>${u}</li>`).join('');
});
