
const express=require('express');
const http=require('http');
const {Server}=require('socket.io');
const app=express();
const server=http.createServer(app);
const io=new Server(server);

app.use(express.static('public'));

let users=[];
let history=[];

io.on('connection',socket=>{
  socket.on('login',name=>{
    socket.username=name;
    if(!users.includes(name)) users.push(name);
    socket.emit('history',history);
    io.emit('users',users);
    io.emit('system', name+' a rejoint le serveur');
  });

  socket.on('message',txt=>{
    const m={user:socket.username,text:txt,time:new Date().toLocaleTimeString()};
    history.push(m);
    io.emit('message',m);
  });

  socket.on('disconnect',()=>{
    users=users.filter(u=>u!==socket.username);
    io.emit('users',users);
  });
});

server.listen(process.env.PORT||3000);
